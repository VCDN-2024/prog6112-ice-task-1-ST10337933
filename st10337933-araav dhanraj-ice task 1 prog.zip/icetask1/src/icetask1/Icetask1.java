package icetask1;

import java.util.Scanner;

/**
 * Main class to handle the bookstore inventory.
 * Author: Araav
 */
public class Icetask1 {

    /**
     * Main method to execute the bookstore sorting task.
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Phase 1: Create an array with five book titles
        String[] bookTitles = {
            "Harry Potter",
            "The Great Gatsby",
            "To Kill a Mockingbird",
            "Pride and Prejudice",
            "Othello"
        };

        // Phase 4: Prompt the user for sorting choice (ascending or descending)
        Scanner scanner = new Scanner(System.in); // Scanner object to take user input
        System.out.println("How would you like to sort the books?");
        System.out.println("Enter 1 for Ascending order, or 2 for Descending order:");
        int choice = scanner.nextInt(); // Store user's choice

        // Check user input and call the corresponding sort method
        if (choice == 1) {
            // Call insertion sort for ascending order
            insertionSortAscending(bookTitles);
            System.out.println("Books sorted in ascending order:");
        } else if (choice == 2) {
            // Call insertion sort for descending order
            insertionSortDescending(bookTitles);
            System.out.println("Books sorted in descending order:");
        } else {
            System.out.println("Invalid choice. Please enter 1 or 2."); // Handle invalid input
            return; // Exit the program for invalid input
        }

        // Phase 4: Display sorted books
        for (String title : bookTitles) {
            System.out.println(title); // Print each book title after sorting
        }

        scanner.close(); // Close the scanner object
    }

    // Phase 2: Insertion sort for ascending order
    public static void insertionSortAscending(String[] array) {
        // Outer loop: iterate over all elements in the array (starting from the second element)
        for (int i = 1; i < array.length; i++) {
            String key = array[i]; // Key is the current element we want to insert at the right position
            int j = i - 1;

            // Inner loop: shift elements to the right to make space for the key
            while (j >= 0 && array[j].compareTo(key) > 0) { // compareTo returns > 0 if the current element is greater than the key
                array[j + 1] = array[j]; // Shift the element one position to the right
                j--;
            }
            array[j + 1] = key; // Place the key in its correct position
        }
    }

    // Phase 3: Insertion sort for descending order
    public static void insertionSortDescending(String[] array) {
        // Outer loop: iterate over all elements in the array (starting from the second element)
        for (int i = 1; i < array.length; i++) {
            String key = array[i]; // Key is the current element we want to insert at the right position
            int j = i - 1;

            // Inner loop: shift elements to the right to make space for the key
            while (j >= 0 && array[j].compareTo(key) < 0) { // compareTo returns < 0 if the current element is smaller than the key
                array[j + 1] = array[j]; // Shift the element one position to the right
                j--;
            }
            array[j + 1] = key; // Place the key in its correct position
        }
    }
}

